//Hasan Ali Syed 22I-0919 CS-H Project
/* PROGRAMMING FUNDAMENTAL'S PROJECT FOR FALL 2022 BS(CS)
 * You need to define the required function in the part instructed here below.
 * Avoid making any unnecessary changes, particularly the ones you don't understand.
 * The different pieces should be defined using an array - uncomment the following code once you are done creating the array.
 * TIP: Understand thoroughly before getting started with coding.
 * */

//---Piece Starts to Fall When Game Starts---//
void fallingPiece(float &timer, double &delay, int &colorNum){
    if (timer>delay){
        for (int i=0;i<4;i++){
            point_2[i][0]=point_1[i][0];
            point_2[i][1]=point_1[i][1];
            point_1[i][1]+=1;                   //How much units downward
        }
        delay=0.3;
        if (!anamoly()){
            for (int i=0;i<4;i++)
            	gameGrid[point_2[i][1]][point_2[i][0]] = colorNum;
            colorNum=1+rand()%7;	
            int n=rand()%7;
            //--- Un-Comment this Part When You Make BLOCKS array---//
            
                for (int i=0;i<4;i++){
                    point_1[i][0] = BLOCKS[n][i] % 2;
                    point_1[i][1] = BLOCKS[n][i] / 2;
                }
            
        }
        timer=0;
    }
}

/////////////////////////////////////////////
///*** START CODING YOUR FUNTIONS HERE ***///	
void lmovement(int &delta_x){
	 for (int i=0;i<4;i++){
            point_2[i][0]=point_1[i][0];
            point_2[i][1]=point_1[i][1];		//copying shape of blocks from one array to another temporarliy 
            point_1[i][0]+=delta_x;                  //shifting the block according to input
        }	
        delta_x=0;
        switch(anamoly()){			//check for making sure if block is inside the grid
        	case 0:
        		 int b=0;
        		 while (b<4){
        		 	point_1[b][0]=point_2[b][0];
        		 	point_1[b][1]=point_2[b][1];
        		 	b++;
        		 }
        		 break;
        	}        						
}

void rotatep(bool &rotate){
	switch (rotate==1){
		case 1:
			int r=0;
			int i;
			int j;
			while (r<4){
				j=point_1[r][0]-point_1[1][0];			//transposing array for rotation
				i=point_1[r][1]-point_1[1][1];
				point_1[r][1]=point_1[1][1]+j;
				point_1[r][0]=point_1[1][0]-i;
				r++;
			}
			rotate=0;
			if (!anamoly()){		//checking if after rotation the block does not interfere with boundaries
				int s=0;
				while (s<4){
					point_1[s][0]=point_2[s][0];
					point_1[s][1]=point_2[s][1];
					s++;
				}
			}
			break;
	}
}					

bool gameclose(){		//fucntion check top row of grid for presence of a block and gives appropriate return 
	if ((gameGrid[0][0]!=0)||(gameGrid[0][1]!=0)||(gameGrid[0][2]!=0)||(gameGrid[0][3]!=0)||(gameGrid[0][4]!=0)||(gameGrid[0][5]!=0)||(gameGrid[0][6]!=0)||(gameGrid[0][7]!=0)||(gameGrid[0][8]!=0)||(gameGrid[0][9]!=0))
		return true;	//true returned in the case there is a blcok in the top most row
}

void removerow (){		//function removes row when it becomes full
	int g=19;
	for (int i=g;i>0;i--){
		int index=0;
		int h=index;
		while (h<10){
			switch (gameGrid[i][h]){
				case 0:		//if there is empty space look to line above
					gameGrid[g][h]=gameGrid[i][h]; 
					break;
				default :
					index++;
					break;
				}
			h++;	
		}
		if (!(index>=10))
			g=g-1;
	}
}	

																
///*** YOUR FUNCTIONS END HERE ***///
/////////////////////////////////////
