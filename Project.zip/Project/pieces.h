//Hasan Ali Syed 22I-0919 CS-H Project
/* PROGRAMMING FUNDAMENTAL'S PROJECT FOR FALL 2022 BS(CS)
 * Shape of each piece is represented by rows in the array.
 * TIP: Name the array what is already been coded to avoid any unwanted errors.
 */
 int BLOCKS[7][4]={
 	{0,1,2,3},
 	{0,2,4,6},
 	{0,2,4,5},
 	{1,3,4,5},
 	{0,2,3,4},
 	{0,2,3,5},
 	{1,2,3,4}
 	}; 
 					
